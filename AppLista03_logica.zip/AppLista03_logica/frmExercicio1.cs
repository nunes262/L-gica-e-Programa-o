﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_logica
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Pegar valores na tela
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            //Calcular soma
            soma = num1 + num3;

            //Mostrar resultado
            MessageBox.Show("Soma = "+ soma);
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            //Pegar valores na tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;

            //Calcular a média
            media = (num1 + num2 + num3) / 3;

            //Mostrar resultado
            MessageBox.Show("Media = " + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            //Pegar resultados na tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float porcentagem1,porcentagem2,porcentagem3;

            //Calcular porcentagem
            porcentagem1 = num1 / (num1 + num2 + num3) * 100;
            porcentagem2 = num2/ (num1 + num2 + num3) * 100;
            porcentagem3 = num3/ (num1 + num2 + num3) * 100;

            //Mostrar resultado
            MessageBox.Show("Porcentagem igual" + porcentagem1);
            MessageBox.Show("Porcentagem igual" + porcentagem2);
            MessageBox.Show("Porcentagem igual" + porcentagem3);

        }
    }
}
