﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppRaizQuadrada
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            float N1 = float.Parse(txtN1.Text);
            float resultado;

            resultado = N1 Math.Pow(N1,0.5f);
        }
    }
}
