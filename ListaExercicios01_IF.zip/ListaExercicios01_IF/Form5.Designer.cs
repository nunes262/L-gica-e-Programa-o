﻿namespace ListaExercicios01_IF
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform4 = new System.Windows.Forms.ToolStripMenuItem();
            this.questão05ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questao06ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpreço = new System.Windows.Forms.TextBox();
            this.txtvalop = new System.Windows.Forms.TextBox();
            this.btntroco = new System.Windows.Forms.Button();
            this.questao07ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(579, 25);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirform1,
            this.exibirform2,
            this.exibirform3,
            this.exibirform4,
            this.questão05ToolStripMenuItem,
            this.questao06ToolStripMenuItem,
            this.questao07ToolStripMenuItem});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(48, 19);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirform1
            // 
            this.exibirform1.Image = ((System.Drawing.Image)(resources.GetObject("exibirform1.Image")));
            this.exibirform1.Name = "exibirform1";
            this.exibirform1.Size = new System.Drawing.Size(180, 22);
            this.exibirform1.Text = "Questão 01";
            this.exibirform1.Click += new System.EventHandler(this.exibirform1_Click);
            // 
            // exibirform2
            // 
            this.exibirform2.Image = ((System.Drawing.Image)(resources.GetObject("exibirform2.Image")));
            this.exibirform2.Name = "exibirform2";
            this.exibirform2.Size = new System.Drawing.Size(180, 22);
            this.exibirform2.Text = "Questão 02";
            this.exibirform2.Click += new System.EventHandler(this.exibirform2_Click);
            // 
            // exibirform3
            // 
            this.exibirform3.Image = ((System.Drawing.Image)(resources.GetObject("exibirform3.Image")));
            this.exibirform3.Name = "exibirform3";
            this.exibirform3.Size = new System.Drawing.Size(180, 22);
            this.exibirform3.Text = "Questão 03";
            this.exibirform3.Click += new System.EventHandler(this.exibirform3_Click);
            // 
            // exibirform4
            // 
            this.exibirform4.Image = ((System.Drawing.Image)(resources.GetObject("exibirform4.Image")));
            this.exibirform4.Name = "exibirform4";
            this.exibirform4.Size = new System.Drawing.Size(180, 22);
            this.exibirform4.Text = "Questão 04";
            this.exibirform4.Click += new System.EventHandler(this.exibirform4_Click);
            // 
            // questão05ToolStripMenuItem
            // 
            this.questão05ToolStripMenuItem.Name = "questão05ToolStripMenuItem";
            this.questão05ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão05ToolStripMenuItem.Text = "Questão 05";
            this.questão05ToolStripMenuItem.Click += new System.EventHandler(this.questão05ToolStripMenuItem_Click);
            // 
            // questao06ToolStripMenuItem
            // 
            this.questao06ToolStripMenuItem.Name = "questao06ToolStripMenuItem";
            this.questao06ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao06ToolStripMenuItem.Text = "Questao 06";
            this.questao06ToolStripMenuItem.Click += new System.EventHandler(this.questao06ToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(73, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "preço do salgado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "valor pago";
            // 
            // txtpreço
            // 
            this.txtpreço.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpreço.Location = new System.Drawing.Point(76, 140);
            this.txtpreço.Name = "txtpreço";
            this.txtpreço.Size = new System.Drawing.Size(150, 35);
            this.txtpreço.TabIndex = 5;
            // 
            // txtvalop
            // 
            this.txtvalop.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvalop.Location = new System.Drawing.Point(76, 323);
            this.txtvalop.Name = "txtvalop";
            this.txtvalop.Size = new System.Drawing.Size(150, 35);
            this.txtvalop.TabIndex = 6;
            // 
            // btntroco
            // 
            this.btntroco.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntroco.Location = new System.Drawing.Point(340, 208);
            this.btntroco.Name = "btntroco";
            this.btntroco.Size = new System.Drawing.Size(149, 59);
            this.btntroco.TabIndex = 7;
            this.btntroco.Text = "troco";
            this.btntroco.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btntroco.UseVisualStyleBackColor = true;
            this.btntroco.Click += new System.EventHandler(this.btntroco_Click);
            // 
            // questao07ToolStripMenuItem
            // 
            this.questao07ToolStripMenuItem.Name = "questao07ToolStripMenuItem";
            this.questao07ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao07ToolStripMenuItem.Text = "Questao 07";
            this.questao07ToolStripMenuItem.Click += new System.EventHandler(this.questao07ToolStripMenuItem_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 404);
            this.Controls.Add(this.btntroco);
            this.Controls.Add(this.txtvalop);
            this.Controls.Add(this.txtpreço);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form5";
            this.Text = "Form5";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirform1;
        private System.Windows.Forms.ToolStripMenuItem exibirform2;
        private System.Windows.Forms.ToolStripMenuItem exibirform3;
        private System.Windows.Forms.ToolStripMenuItem exibirform4;
        private System.Windows.Forms.ToolStripMenuItem questão05ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtpreço;
        private System.Windows.Forms.TextBox txtvalop;
        private System.Windows.Forms.Button btntroco;
        private System.Windows.Forms.ToolStripMenuItem questao06ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questao07ToolStripMenuItem;
    }
}