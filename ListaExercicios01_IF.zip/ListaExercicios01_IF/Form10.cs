﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float peso = float.Parse(textBox2.Text);
            float altura = float.Parse(textBox1.Text);
            float resultado = (peso / (altura * altura));

            if (resultado < 18.5)
            {
                MessageBox.Show("abaixo do peso");
            }
            else (resultado < 25 || resultado > 18.5f)
            {
                MessageBox.Show("peso normal");
            }
            if (resultado > 25 || resultado < 30)
            {
                MessageBox.Show(" acima do peso");
            }
            else (resultado > 30)
            {
                MessageBox.Show("obesidade");
            }
        }
    }
}
