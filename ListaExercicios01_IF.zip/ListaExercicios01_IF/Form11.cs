﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_IF
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float preco = float.Parse(txtpreco.Text);
            string pagamento = (txtformadepag.Text);
            float resultado;

            if (pagamento == "dinheiro")
            {
                resultado = (((preco * 10) / 100) - preco);
                MessageBox.Show("o preço é " + resultado);
            }
            else (pagamento == "cartao de credito")
            {
                resultado = (((preco * 15) / 100) - preco);
                MessageBox.Show(" o preço é " + resultado);
            }
            if (pagamento == "duas vezes sem juros")
            {
                MessageBox.Show("o preço  é " + preco);
            }
            else ( pagamento == "duas vezes com juros")
            {
                resultado = (((preco * 10) / 100) + preco);
                MessageBox.Show("o preço com juros é " + resultado);
            }
        }
    }
}
