﻿namespace ListaExercicios01_IF
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform4 = new System.Windows.Forms.ToolStripMenuItem();
            this.questão05ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questao06ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbltitulo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtValor01 = new System.Windows.Forms.TextBox();
            this.txtValor02 = new System.Windows.Forms.TextBox();
            this.btnTestar = new System.Windows.Forms.Button();
            this.questão07ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirform1,
            this.exibirform2,
            this.exibirform3,
            this.exibirform4,
            this.questão05ToolStripMenuItem,
            this.questao06ToolStripMenuItem,
            this.questão07ToolStripMenuItem});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirform1
            // 
            this.exibirform1.Image = ((System.Drawing.Image)(resources.GetObject("exibirform1.Image")));
            this.exibirform1.Name = "exibirform1";
            this.exibirform1.Size = new System.Drawing.Size(180, 22);
            this.exibirform1.Text = "Questão 01";
            this.exibirform1.Click += new System.EventHandler(this.exibirform1_Click);
            // 
            // exibirform2
            // 
            this.exibirform2.Image = ((System.Drawing.Image)(resources.GetObject("exibirform2.Image")));
            this.exibirform2.Name = "exibirform2";
            this.exibirform2.Size = new System.Drawing.Size(180, 22);
            this.exibirform2.Text = "Questão 02";
            this.exibirform2.Click += new System.EventHandler(this.exibirform2_Click);
            // 
            // exibirform3
            // 
            this.exibirform3.Image = ((System.Drawing.Image)(resources.GetObject("exibirform3.Image")));
            this.exibirform3.Name = "exibirform3";
            this.exibirform3.Size = new System.Drawing.Size(180, 22);
            this.exibirform3.Text = "Questão 03";
            this.exibirform3.Click += new System.EventHandler(this.exibirform3_Click);
            // 
            // exibirform4
            // 
            this.exibirform4.Image = ((System.Drawing.Image)(resources.GetObject("exibirform4.Image")));
            this.exibirform4.Name = "exibirform4";
            this.exibirform4.Size = new System.Drawing.Size(180, 22);
            this.exibirform4.Text = "Questão 04";
            this.exibirform4.Click += new System.EventHandler(this.exibirform4_Click);
            // 
            // questão05ToolStripMenuItem
            // 
            this.questão05ToolStripMenuItem.Name = "questão05ToolStripMenuItem";
            this.questão05ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão05ToolStripMenuItem.Text = "Questão 05";
            this.questão05ToolStripMenuItem.Click += new System.EventHandler(this.questão05ToolStripMenuItem_Click);
            // 
            // questao06ToolStripMenuItem
            // 
            this.questao06ToolStripMenuItem.Name = "questao06ToolStripMenuItem";
            this.questao06ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao06ToolStripMenuItem.Text = "Questao 06";
            this.questao06ToolStripMenuItem.Click += new System.EventHandler(this.questao06ToolStripMenuItem_Click);
            // 
            // lbltitulo
            // 
            this.lbltitulo.AutoSize = true;
            this.lbltitulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbltitulo.Font = new System.Drawing.Font("Arial Narrow", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitulo.Location = new System.Drawing.Point(285, 63);
            this.lbltitulo.Name = "lbltitulo";
            this.lbltitulo.Size = new System.Drawing.Size(218, 44);
            this.lbltitulo.TabIndex = 2;
            this.lbltitulo.Text = "EXERCÍCIO 01";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "VALOR 01";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(89, 283);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "VALOR 02";
            // 
            // txtValor01
            // 
            this.txtValor01.Location = new System.Drawing.Point(216, 196);
            this.txtValor01.Name = "txtValor01";
            this.txtValor01.Size = new System.Drawing.Size(169, 20);
            this.txtValor01.TabIndex = 5;
            // 
            // txtValor02
            // 
            this.txtValor02.Location = new System.Drawing.Point(216, 288);
            this.txtValor02.Name = "txtValor02";
            this.txtValor02.Size = new System.Drawing.Size(169, 20);
            this.txtValor02.TabIndex = 6;
            // 
            // btnTestar
            // 
            this.btnTestar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTestar.Location = new System.Drawing.Point(505, 204);
            this.btnTestar.Name = "btnTestar";
            this.btnTestar.Size = new System.Drawing.Size(227, 84);
            this.btnTestar.TabIndex = 7;
            this.btnTestar.Text = "TESTAR";
            this.btnTestar.UseVisualStyleBackColor = true;
            this.btnTestar.Click += new System.EventHandler(this.btnTestar_Click);
            // 
            // questão07ToolStripMenuItem
            // 
            this.questão07ToolStripMenuItem.Name = "questão07ToolStripMenuItem";
            this.questão07ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão07ToolStripMenuItem.Text = "Questão 07";
            this.questão07ToolStripMenuItem.Click += new System.EventHandler(this.questão07ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnTestar);
            this.Controls.Add(this.txtValor02);
            this.Controls.Add(this.txtValor01);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbltitulo);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirform1;
        private System.Windows.Forms.ToolStripMenuItem exibirform2;
        private System.Windows.Forms.ToolStripMenuItem exibirform3;
        private System.Windows.Forms.ToolStripMenuItem exibirform4;
        private System.Windows.Forms.Label lbltitulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtValor01;
        private System.Windows.Forms.TextBox txtValor02;
        private System.Windows.Forms.Button btnTestar;
        private System.Windows.Forms.ToolStripMenuItem questão05ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questao06ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questão07ToolStripMenuItem;
    }
}

