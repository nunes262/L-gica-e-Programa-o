﻿namespace ListaExercicios01_IF
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform4 = new System.Windows.Forms.ToolStripMenuItem();
            this.questão05ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questao06ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtlados = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.questao07ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(209, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirform1,
            this.exibirform2,
            this.exibirform3,
            this.exibirform4,
            this.questão05ToolStripMenuItem,
            this.questao06ToolStripMenuItem,
            this.questao07ToolStripMenuItem});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirform1
            // 
            this.exibirform1.Image = ((System.Drawing.Image)(resources.GetObject("exibirform1.Image")));
            this.exibirform1.Name = "exibirform1";
            this.exibirform1.Size = new System.Drawing.Size(180, 22);
            this.exibirform1.Text = "Questão 01";
            this.exibirform1.Click += new System.EventHandler(this.exibirform1_Click);
            // 
            // exibirform2
            // 
            this.exibirform2.Image = ((System.Drawing.Image)(resources.GetObject("exibirform2.Image")));
            this.exibirform2.Name = "exibirform2";
            this.exibirform2.Size = new System.Drawing.Size(180, 22);
            this.exibirform2.Text = "Questão 02";
            this.exibirform2.Click += new System.EventHandler(this.exibirform2_Click);
            // 
            // exibirform3
            // 
            this.exibirform3.Image = ((System.Drawing.Image)(resources.GetObject("exibirform3.Image")));
            this.exibirform3.Name = "exibirform3";
            this.exibirform3.Size = new System.Drawing.Size(180, 22);
            this.exibirform3.Text = "Questão 03";
            this.exibirform3.Click += new System.EventHandler(this.exibirform3_Click);
            // 
            // exibirform4
            // 
            this.exibirform4.Image = ((System.Drawing.Image)(resources.GetObject("exibirform4.Image")));
            this.exibirform4.Name = "exibirform4";
            this.exibirform4.Size = new System.Drawing.Size(180, 22);
            this.exibirform4.Text = "Questão 04";
            this.exibirform4.Click += new System.EventHandler(this.exibirform4_Click);
            // 
            // questão05ToolStripMenuItem
            // 
            this.questão05ToolStripMenuItem.Name = "questão05ToolStripMenuItem";
            this.questão05ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão05ToolStripMenuItem.Text = "Questão 05";
            this.questão05ToolStripMenuItem.Click += new System.EventHandler(this.questão05ToolStripMenuItem_Click);
            // 
            // questao06ToolStripMenuItem
            // 
            this.questao06ToolStripMenuItem.Name = "questao06ToolStripMenuItem";
            this.questao06ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao06ToolStripMenuItem.Text = "Questao 06";
            this.questao06ToolStripMenuItem.Click += new System.EventHandler(this.questao06ToolStripMenuItem_Click);
            // 
            // txtlados
            // 
            this.txtlados.Location = new System.Drawing.Point(27, 210);
            this.txtlados.Name = "txtlados";
            this.txtlados.Size = new System.Drawing.Size(150, 20);
            this.txtlados.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "quantidades de lados";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(59, 288);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 36);
            this.button1.TabIndex = 4;
            this.button1.Text = "PESQUISAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // questao07ToolStripMenuItem
            // 
            this.questao07ToolStripMenuItem.Name = "questao07ToolStripMenuItem";
            this.questao07ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao07ToolStripMenuItem.Text = "Questao 07";
            this.questao07ToolStripMenuItem.Click += new System.EventHandler(this.questao07ToolStripMenuItem_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(209, 405);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtlados);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form6";
            this.Text = "Form6";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirform1;
        private System.Windows.Forms.ToolStripMenuItem exibirform2;
        private System.Windows.Forms.ToolStripMenuItem exibirform3;
        private System.Windows.Forms.ToolStripMenuItem exibirform4;
        private System.Windows.Forms.ToolStripMenuItem questão05ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questao06ToolStripMenuItem;
        private System.Windows.Forms.TextBox txtlados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem questao07ToolStripMenuItem;
    }
}