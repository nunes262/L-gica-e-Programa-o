﻿namespace ListaExercicios01_IF
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform4 = new System.Windows.Forms.ToolStripMenuItem();
            this.questão05ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questao06ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbllogin = new System.Windows.Forms.Label();
            this.txtadd = new System.Windows.Forms.TextBox();
            this.txtsenha = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.questao07ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(756, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirform1,
            this.exibirform2,
            this.exibirform3,
            this.exibirform4,
            this.questão05ToolStripMenuItem,
            this.questao06ToolStripMenuItem,
            this.questao07ToolStripMenuItem});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.exibirToolStripMenuItem.Text = "uestao ";
            // 
            // exibirform1
            // 
            this.exibirform1.Image = ((System.Drawing.Image)(resources.GetObject("exibirform1.Image")));
            this.exibirform1.Name = "exibirform1";
            this.exibirform1.Size = new System.Drawing.Size(180, 22);
            this.exibirform1.Text = "Questão 01";
            this.exibirform1.Click += new System.EventHandler(this.exibirform1_Click);
            // 
            // exibirform2
            // 
            this.exibirform2.Image = ((System.Drawing.Image)(resources.GetObject("exibirform2.Image")));
            this.exibirform2.Name = "exibirform2";
            this.exibirform2.Size = new System.Drawing.Size(180, 22);
            this.exibirform2.Text = "Questão 02";
            this.exibirform2.Click += new System.EventHandler(this.exibirform2_Click);
            // 
            // exibirform3
            // 
            this.exibirform3.Image = ((System.Drawing.Image)(resources.GetObject("exibirform3.Image")));
            this.exibirform3.Name = "exibirform3";
            this.exibirform3.Size = new System.Drawing.Size(180, 22);
            this.exibirform3.Text = "Questão 03";
            this.exibirform3.Click += new System.EventHandler(this.exibirform3_Click);
            // 
            // exibirform4
            // 
            this.exibirform4.Image = ((System.Drawing.Image)(resources.GetObject("exibirform4.Image")));
            this.exibirform4.Name = "exibirform4";
            this.exibirform4.Size = new System.Drawing.Size(180, 22);
            this.exibirform4.Text = "Questão 04";
            this.exibirform4.Click += new System.EventHandler(this.exibirform4_Click);
            // 
            // questão05ToolStripMenuItem
            // 
            this.questão05ToolStripMenuItem.Name = "questão05ToolStripMenuItem";
            this.questão05ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão05ToolStripMenuItem.Text = "Questão 05";
            this.questão05ToolStripMenuItem.Click += new System.EventHandler(this.questão05ToolStripMenuItem_Click);
            // 
            // questao06ToolStripMenuItem
            // 
            this.questao06ToolStripMenuItem.Name = "questao06ToolStripMenuItem";
            this.questao06ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao06ToolStripMenuItem.Text = "Questao 06";
            // 
            // lbllogin
            // 
            this.lbllogin.AutoSize = true;
            this.lbllogin.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllogin.Location = new System.Drawing.Point(62, 59);
            this.lbllogin.Name = "lbllogin";
            this.lbllogin.Size = new System.Drawing.Size(64, 25);
            this.lbllogin.TabIndex = 2;
            this.lbllogin.Text = "LOGIN";
            // 
            // txtadd
            // 
            this.txtadd.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadd.Location = new System.Drawing.Point(53, 87);
            this.txtadd.Name = "txtadd";
            this.txtadd.Size = new System.Drawing.Size(243, 32);
            this.txtadd.TabIndex = 4;
            // 
            // txtsenha
            // 
            this.txtsenha.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsenha.Location = new System.Drawing.Point(53, 216);
            this.txtsenha.Name = "txtsenha";
            this.txtsenha.Size = new System.Drawing.Size(243, 32);
            this.txtsenha.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "SENHA";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(482, 87);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(213, 142);
            this.button1.TabIndex = 7;
            this.button1.Text = "ENTRAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // questao07ToolStripMenuItem
            // 
            this.questao07ToolStripMenuItem.Name = "questao07ToolStripMenuItem";
            this.questao07ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao07ToolStripMenuItem.Text = "Questao 07";
            this.questao07ToolStripMenuItem.Click += new System.EventHandler(this.questao07ToolStripMenuItem_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(756, 309);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsenha);
            this.Controls.Add(this.txtadd);
            this.Controls.Add(this.lbllogin);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirform1;
        private System.Windows.Forms.ToolStripMenuItem exibirform2;
        private System.Windows.Forms.ToolStripMenuItem exibirform3;
        private System.Windows.Forms.ToolStripMenuItem exibirform4;
        private System.Windows.Forms.Label lbllogin;
        private System.Windows.Forms.TextBox txtadd;
        private System.Windows.Forms.TextBox txtsenha;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem questão05ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questao06ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questao07ToolStripMenuItem;
    }
}