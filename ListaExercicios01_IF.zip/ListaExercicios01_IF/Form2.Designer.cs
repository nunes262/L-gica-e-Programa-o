﻿namespace ListaExercicios01_IF
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirform4 = new System.Windows.Forms.ToolStripMenuItem();
            this.questão05ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questao06ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbltitulo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAnoNasci = new System.Windows.Forms.TextBox();
            this.btnTestar = new System.Windows.Forms.Button();
            this.questao07ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(780, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirform1,
            this.exibirform2,
            this.exibirform3,
            this.exibirform4,
            this.questão05ToolStripMenuItem,
            this.questao06ToolStripMenuItem,
            this.questao07ToolStripMenuItem});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(48, 19);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirform1
            // 
            this.exibirform1.Image = ((System.Drawing.Image)(resources.GetObject("exibirform1.Image")));
            this.exibirform1.Name = "exibirform1";
            this.exibirform1.Size = new System.Drawing.Size(180, 22);
            this.exibirform1.Text = "Questão 01";
            this.exibirform1.Click += new System.EventHandler(this.exibirform1_Click);
            // 
            // exibirform2
            // 
            this.exibirform2.Image = ((System.Drawing.Image)(resources.GetObject("exibirform2.Image")));
            this.exibirform2.Name = "exibirform2";
            this.exibirform2.Size = new System.Drawing.Size(180, 22);
            this.exibirform2.Text = "Questão 02";
            this.exibirform2.Click += new System.EventHandler(this.exibirform2_Click);
            // 
            // exibirform3
            // 
            this.exibirform3.Image = ((System.Drawing.Image)(resources.GetObject("exibirform3.Image")));
            this.exibirform3.Name = "exibirform3";
            this.exibirform3.Size = new System.Drawing.Size(180, 22);
            this.exibirform3.Text = "Questão 03";
            this.exibirform3.Click += new System.EventHandler(this.exibirform3_Click);
            // 
            // exibirform4
            // 
            this.exibirform4.Image = ((System.Drawing.Image)(resources.GetObject("exibirform4.Image")));
            this.exibirform4.Name = "exibirform4";
            this.exibirform4.Size = new System.Drawing.Size(180, 22);
            this.exibirform4.Text = "Questão 04";
            this.exibirform4.Click += new System.EventHandler(this.exibirform4_Click);
            // 
            // questão05ToolStripMenuItem
            // 
            this.questão05ToolStripMenuItem.Name = "questão05ToolStripMenuItem";
            this.questão05ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questão05ToolStripMenuItem.Text = "Questão 05";
            this.questão05ToolStripMenuItem.Click += new System.EventHandler(this.questão05ToolStripMenuItem_Click);
            // 
            // questao06ToolStripMenuItem
            // 
            this.questao06ToolStripMenuItem.Name = "questao06ToolStripMenuItem";
            this.questao06ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao06ToolStripMenuItem.Text = "Questao 06";
            this.questao06ToolStripMenuItem.Click += new System.EventHandler(this.questao06ToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(85, 319);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ano de nascimento:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(297, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 3;
            // 
            // lbltitulo
            // 
            this.lbltitulo.AutoSize = true;
            this.lbltitulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbltitulo.Font = new System.Drawing.Font("Arial Narrow", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitulo.Location = new System.Drawing.Point(301, 83);
            this.lbltitulo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbltitulo.Name = "lbltitulo";
            this.lbltitulo.Size = new System.Drawing.Size(218, 44);
            this.lbltitulo.TabIndex = 4;
            this.lbltitulo.Text = "EXERCÍCIO 01";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(105, 445);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 5;
            // 
            // txtAnoNasci
            // 
            this.txtAnoNasci.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnoNasci.Location = new System.Drawing.Point(91, 383);
            this.txtAnoNasci.Margin = new System.Windows.Forms.Padding(5);
            this.txtAnoNasci.Name = "txtAnoNasci";
            this.txtAnoNasci.Size = new System.Drawing.Size(257, 38);
            this.txtAnoNasci.TabIndex = 7;
            // 
            // btnTestar
            // 
            this.btnTestar.Location = new System.Drawing.Point(440, 300);
            this.btnTestar.Margin = new System.Windows.Forms.Padding(5);
            this.btnTestar.Name = "btnTestar";
            this.btnTestar.Size = new System.Drawing.Size(272, 121);
            this.btnTestar.TabIndex = 8;
            this.btnTestar.Text = "Constatar";
            this.btnTestar.UseVisualStyleBackColor = true;
            this.btnTestar.Click += new System.EventHandler(this.btnTestar_Click);
            // 
            // questao07ToolStripMenuItem
            // 
            this.questao07ToolStripMenuItem.Name = "questao07ToolStripMenuItem";
            this.questao07ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.questao07ToolStripMenuItem.Text = "Questao 07";
            this.questao07ToolStripMenuItem.Click += new System.EventHandler(this.questao07ToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(780, 492);
            this.Controls.Add(this.btnTestar);
            this.Controls.Add(this.txtAnoNasci);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbltitulo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirform1;
        private System.Windows.Forms.ToolStripMenuItem exibirform2;
        private System.Windows.Forms.ToolStripMenuItem exibirform3;
        private System.Windows.Forms.ToolStripMenuItem exibirform4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbltitulo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAnoNasci;
        private System.Windows.Forms.Button btnTestar;
        private System.Windows.Forms.ToolStripMenuItem questão05ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questao06ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem questao07ToolStripMenuItem;
    }
}