﻿using System;
using System.Windows.Forms;

namespace CaluladoraN2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)

        {
            float varNum1 = float.Parse(txtVar1.Text);
            float varNum2 = float.Parse(txtVar2.Text);
            float resultado;

            //Soma;
            resultado = varNum1 + varNum2;
            MessageBox.Show("Soma:" + resultado);


        }

        private void btnSubtração_Click(object sender, EventArgs e)

        {
            float varNum1 = float.Parse(txtVar1.Text);
            float varNum2 = float.Parse(txtVar2.Text);
            float resultado;

            //Subtração;
            resultado = varNum1 - varNum2;
            MessageBox.Show("Subtração:" + resultado);
        }

        private void btnMultiplicação_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtVar1.Text);
            float varNum2 = float.Parse(txtVar2.Text);
            float resultado;

            //Multiplicação
            resultado = varNum1 * varNum2;
            MessageBox.Show("Multiplicação:" + resultado);
        }

        private void btnDivisão_Click(object sender, EventArgs e)
        {
            float varNum1 = float.Parse(txtVar1.Text);
            float varNum2 = float.Parse(txtVar2.Text);
            float resultado;

            //Divisão;
            resultado = varNum1 / varNum2;
            MessageBox.Show("Divisão:" + resultado);
        }
    }
}
